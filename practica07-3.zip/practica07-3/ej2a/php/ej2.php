<?php
	$nombre=$_REQUEST["nombre"];
	$apellidos=$_REQUEST["apellidos"];
	$modulo = $_REQUEST["modulo"];
	$nota=rand(4,10);
	echo $nota;
?>