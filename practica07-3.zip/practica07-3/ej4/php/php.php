<?php
	$nombre=$_POST["nombre"];
	$apellidos=$_POST["apellidos"];
	$puesto = $_POST["puesto"];
	$sueldo = rand(1000,3250);
	echo $sueldo;
?>