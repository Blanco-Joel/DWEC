<?php
	$nombre=$_POST["nombre"];
	$apellidos=$_POST["apellidos"];
	$modulo = $_POST["modulo"];
	$nota=rand(4,10);
	echo $nota;
?>